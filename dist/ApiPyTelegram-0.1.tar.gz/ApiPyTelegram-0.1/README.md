
# ApiPyTelegram | apt 

telegram bots core for python. 
## Installation

Install my-project with pip

```bash
  pip install PyTelegramApi
```
    
## Usage/Examples

```python
import ApiPyTelegram 
ApiPyTelegram.apt() #you token goes here
ApiPyTelegram.message.text(12345, "test you") # first arg is chat id
```
[Get user chat id here](https://t.me/getmyid_bot)

## License

[MIT](https://choosealicense.com/licenses/mit/)






## Documentation

[Documentation](https://linktodocumentation)


## Contributing

Contributions are always welcome!

See `contributing.md` for ways to get started.

Please adhere to this project's `Powered by apt.` .

